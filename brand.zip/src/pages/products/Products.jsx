import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"
import favorite from "../../assets/favorite.png";
import "./products.scss";
import axios from "axios";


const Products = ( { selectCategory, label } ) => {
  const [ allProductData, setAllProductData ] = useState( [] );
  const [ currentPage, setCurrentPage ] = useState( 1 )
  const [ offSet, setOffSet ] = useState( 0 )
  const limit = 10
  const navigate = useNavigate();

  useEffect( () => {

    let filter = "";
    if ( label === "category" ) {
      fetch( `https://api.escuelajs.co/api/v1/products?categoryId=${selectCategory.id}` )
        .then( ( response ) => response.json() )
        .then( ( data ) => setAllProductData( data ) )

      // filter=filter + `categoryId=${selectCategory.id}`
      console.log( "hii" )
    } else {
      console.log( "hello" )
      fetch( `https://api.escuelajs.co/api/v1/products` )
        .then( ( response ) => response.json() )
        .then( ( data ) => console.log( data, "helloData" ) )
    }
  }, [] )


  const handleNext = () => {
    setCurrentPage( currentPage + 1 )
    setOffSet( offSet + limit )

  }

  useEffect( () => {
    axios.get( `https://api.escuelajs.co/api/v1/products/?offset=${offSet}&limit=${limit}` )
      .then( ( response ) => {
        setAllProductData( response.data )
      } )


  }, [ handleNext ] )

  const handlePrevious = () => {
    setCurrentPage( currentPage - 1 )
    setOffSet( offSet - limit )

  }


  const handleProductPreview = ( id ) => {
    navigate( `/product/${id}` );
  };
  return (
    <div className="products">

      {allProductData?.map( ( item ) => {
        return (
          <div className="card">
            <div className="card-img">
              <img
                className="image"
                src={item.images[0]}
                onClick={() => handleProductPreview( item.id )}
              />
            </div>
            <div className="card-content">
              <div className="content-detail">
                <div className="content-price">Rs.{item.price}</div>
                <div className="content-title">{item.title}</div>
              </div>

              <div className="favorite">
                <img className="favorite-image" src={favorite}/>
              </div>
            </div>
          </div>
        );
      } )}

      <div className="pagination">
        <button onClick={handlePrevious}>Previous</button>
        {currentPage}
        <button onClick={handleNext}>Next</button>

      </div>

    </div>
  );
};

export default Products;
